# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from . import housekeeping_report
